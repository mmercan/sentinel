import { Ng4FilterPipe } from './ng4-filter.pipe';

describe('Ng4FilterPipe', () => {
  it('create an instance', () => {
    const pipe = new Ng4FilterPipe();
    expect(pipe).toBeTruthy();
  });
});
