export interface IAppsettingValidate {
  key: string;
  required: boolean;
  type: string;
  action: string;
  parameters?: any;
}
