using AutoMapper;
// using Sentinel.Api.HealthMonitoring.Dto;
// using Sentinel.Api.HealthMonitoring.Model.Product;

namespace Sentinel.Api.HealthMonitoring
{
    public class AutoMapperProfile : Profile
    {
        public AutoMapperProfile()
        {
            //  CreateMap<ProductInfo, ProductInfoV1>()
            //  .ForMember(dest=>dest.)
            //CreateMap<ProductInfoDtoV1, ProductInfo>();
            // .ForMember(dest=>dest.useTabs, opt=>opt )
            //.ForMember(dest => dest., opt => opt.MapFrom(src => $"{src.FirstName} {src.LastName}"));
            //CreateMap<ProductInfo, ProductInfoV1>().ForMember(dest => dest., opt => opt.MapFrom(src => $"{src.FirstName} {src.LastName}"));
        }
    }
}
