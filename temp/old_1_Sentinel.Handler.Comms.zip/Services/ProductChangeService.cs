using System;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Configuration;
using Sentinel.Model.Product;
using Sentinel.Model.Product.Dto;
using Sentinel.Model;
using EasyNetQ;

namespace Sentinel.Handler.Comms.Services
{
    public class ProductChangeService : IHostedService, IDisposable
    {
        private string subscriptionId = "test";
        private readonly ILogger logger;
        //  private Timer _timer;
        private IConfiguration configuration;
        private IBus bus;
        private Task _executingTask;
        private ManualResetEventSlim _ResetEvent = new ManualResetEventSlim(false);

        public ProductChangeService(ILogger<TimedHostedService> logger, IConfiguration configuration, IBus bus)
        {
            this.logger = logger;
            logger.LogCritical("ProductChangeService Contructor trigered");
            this.configuration = configuration;
            this.bus = bus;
        }

        public Task StartAsync(CancellationToken cancellationToken)
        {
            _executingTask = Task.Factory.StartNew(new Action(SubscribeToTopicAsync), TaskCreationOptions.LongRunning);
            if (_executingTask.IsCompleted)
            {
                return _executingTask;
            }
            return Task.CompletedTask;
        }

        public void SubscribeToTopicAsync()
        {
            try
            {
                logger.LogCritical(this.GetType().FullName + " Async Connected to bus");
                // bus.SubscribeAsync<ProductInfoDtoV2>(subscriptionId, message => Task.Factory.StartNew(() =>
                //  {
                //      Handler(message);
                //  }).ContinueWith(task =>
                //  {
                //      if (task.IsCompleted && !task.IsFaulted)
                //      {
                //          logger.LogCritical("Finished processing all messages");
                //      }
                //      else
                //      {
                //          throw new EasyNetQException("Message processing exception - look in the default error queue (broker)");
                //      }
                //  }), x => x.WithTopic("product.newproduct"));
                _ResetEvent.Wait();
            }
            catch (Exception ex)
            {
                logger.LogError("Exception: " + ex.Message);
            }
        }

        private void Handler(ProductInfoDtoV2 state)
        {
            logger.LogCritical(this.GetType().FullName + " Async message ");
        }

        public Task StopAsync(CancellationToken cancellationToken)
        {
            logger.LogCritical(this.GetType().FullName + " Service is stopping.");
            _ResetEvent.Dispose();
            return Task.CompletedTask;
        }

        public void Dispose()
        {
            logger.LogCritical("ProductChangeService Disposed");
        }
    }
}