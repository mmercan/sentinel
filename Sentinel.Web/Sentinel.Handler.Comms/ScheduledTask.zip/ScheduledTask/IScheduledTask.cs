using System;
using System.Threading;
using System.Threading.Tasks;

namespace Sentinel.Handler.Comms
{
    public interface IScheduledTask
    {
        string Schedule { get; }
        // Task ProcessInScope(IServiceProvider serviceProvider);
        Task ProcessInScope(IServiceProvider serviceProvider);
    }
}