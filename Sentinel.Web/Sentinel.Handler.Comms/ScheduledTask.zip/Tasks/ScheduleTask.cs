using System;
using System.Threading;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Hosting;
using System.Threading.Tasks;
using Microsoft.Extensions.DependencyInjection;

namespace Sentinel.Handler.Comms
{
    public class ScheduleTask : ScheduledProcessor, IScheduledTask
    {
        public ScheduleTask(IServiceScopeFactory serviceScopeFactory) : base(serviceScopeFactory)
        {
        }

        public string Schedule => "*/10 * * * *"; //Runs every 10 minutes

        public override Task ProcessInScope(IServiceProvider serviceProvider)
        {
            Console.WriteLine("Processing starts here");
            return Task.CompletedTask;
        }
        // public Task ProcessInScope()
        // {
        //     Console.WriteLine("Processing starts here");
        //     return Task.CompletedTask;
        // }
    }
}